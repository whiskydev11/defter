<?php 

session_start();

require './server/auth_control.php';

require './server/baglan.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  //yoklama işleneceği kısım

    $yokOlanlar = $_POST['yok'] ?? [];
    $gecKalanlar = $_POST['gec'] ?? [];
    $ders = intval($_POST['hangiDers']);

    if (count($yokOlanlar) > 0) {
      foreach ($yokOlanlar as $ogrenci) {
        $stmt = $conn->prepare("INSERT INTO devamsizlik (ogrDevamsizlik, ders, ogrNumara, tarih) VALUES (?, ?, ?, ?)");
        $stmt->execute(["Yok", $ders, intval($ogrenci), date("d.m.Y")]);
      };
    };

    if (count($gecKalanlar) > 0) {
      foreach ($gecKalanlar as $ogrenci2) {
        $stmt = $conn->prepare("INSERT INTO devamsizlik (ogrDevamsizlik, ders, ogrNumara, tarih) VALUES (?, ?, ?, ?)");
        $stmt->execute(["Geç", $ders, intval($ogrenci2), date("d.m.Y")]);
      };
    };

    header("Location: /yonetim.php?s=Yoklama başarıyla kaydedildi.");
};
?>