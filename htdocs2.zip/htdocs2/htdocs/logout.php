<?php
session_start(); 
session_destroy(); 

header("Location: /?s=Başarıyla çıkış yapıldı.");
exit;

?>