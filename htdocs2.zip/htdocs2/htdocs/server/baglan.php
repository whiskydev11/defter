<?php
$conn = new mysqli("localhost", "root", "", "defter");
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}
?>