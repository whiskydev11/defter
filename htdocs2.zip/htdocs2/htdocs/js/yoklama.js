async function yoklama() {
    let sinif = document.getElementById("sinifSec");
    let sube = document.getElementById("subeSec");
    let ders = document.getElementById("dersSec");

    let sinifD = sinif.options[sinif.selectedIndex].text;
    let subeD = sube.options[sube.selectedIndex].text;
    let dersD = ders.options[ders.selectedIndex].text;

    if (sinifD == "Seçim yapın" || subeD == "Seçim yapın" || dersD == "Seçim yapın") {
        window.location.href = "/yoklama.php?e=Lütfen gerekli seçenekleri doldurun.";
        return;
    };

    window.location.href = `/yoklama.php?sinif=${sinifD}&sube=${subeD}&ders=${dersD}`;
    return true;
};