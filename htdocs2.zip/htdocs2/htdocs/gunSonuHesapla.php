<?php
//cronjob ile her saat 17:00 oldugunda calısacak
require './server/baglan.php';

$tarih = date("d.m.Y");

$stmt = $conn->prepare("SELECT * FROM devamsizlik WHERE tarih = ?");
$stmt->execute([$tarih]);
$resultSet = $stmt->get_result();
$yoklama = $resultSet->fetch_all(MYSQLI_ASSOC);

foreach ($yoklama as $veri) {
    $ogrenci = $veri["ogrNumara"];

    if ($veri["ogrDevamsizlik"] == "Yok") {
        $stmt = $conn->prepare("UPDATE ogrenciler SET ozursuz = ozursuz + 1 WHERE numara = ?"); //burası her yok oldugunda tam gün yazıyor. değiştirilecek
        $stmt->execute([$ogrenci]);
    } elseif ($veri["ogrDevamsizlik"] == "Geç") {
        $stmt = $conn->prepare("UPDATE ogrenciler SET gec = gec + 1 WHERE numara = ?"); //burası her geç oldugunda tam gün yazıyor. değiştirilecek
        $stmt->execute([$ogrenci]);
    };
    //burası devamsızlık sistemine göre düzenlenecek + tam ve yarım gün + geç olarak tablo düzenlenecek
};

?>