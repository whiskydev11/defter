<?php

session_start();

require './server/auth_control.php';

require './server/baglan.php';

date_default_timezone_set('Europe/Istanbul');

$suanZaman = date('H:i');

/*
if ($suanZaman >= '08:00' && $suanZaman <= '17:00') {

} else {
  header("Location: /yonetim.php?e=Yoklamalar 08:00 - 17:00 saatleri arasında alınabilmektedir.");
  return;
}
  */
?>

<!doctype html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Dijital Sınıf Defteri</title>
    <link rel="stylesheet" id="css-main" href="css/oneui.min-5.9.css">
    <link rel="stylesheet" href="css/buttons.bootstrap5.min.css">
    <link rel="stylesheet" href="css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="css/responsive.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">
    </head>
<body>
<div id="page-container" class="sidebar-o sidebar-dark enable-page-overlay side-scroll page-header-fixed main-content-narrow page-header-dark dark-mode">
<div id="page-loader" class="show"></div>
  <nav id="sidebar" aria-label="Main Navigation">
  <div class="content-header">
    <a class="fw-semibold text-dual" href="/yonetim.php">
      <span class="smini-visible">
        <i class="fa fa-circle-notch text-primary"></i>
      </span>
      <span class="smini-hide fs-5 tracking-wider">DSD</span>
    </a>
    <div>
      <button type="button" class="btn btn-sm btn-alt-secondary" data-toggle="layout" data-action="dark_mode_toggle">
        <i class="far fa-moon"></i>
      </button>
      <div class="dropdown d-inline-block ms-1">
        <button type="button" class="btn btn-sm btn-alt-secondary" id="sidebar-themes-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-brush"></i>
        </button>
        <div class="dropdown-menu dropdown-menu-end fs-sm smini-hide border-0" aria-labelledby="sidebar-themes-dropdown">
          <a class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="default" href="#">
            <span>Default</span>
            <i class="fa fa-circle text-default"></i>
          </a>
          <a class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="css/themes/amethyst.min-5.9.css" href="#">
            <span>Amethyst</span>
            <i class="fa fa-circle text-amethyst"></i>
          </a>
          <a class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="css/themes/city.min-5.9.css" href="#">
            <span>City</span>
            <i class="fa fa-circle text-city"></i>
          </a>
          <a class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="css/themes/flat.min-5.9.css" href="#">
            <span>Flat</span>
            <i class="fa fa-circle text-flat"></i>
          </a>
          <a class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="css/themes/modern.min-5.9.css" href="#">
            <span>Modern</span>
            <i class="fa fa-circle text-modern"></i>
          </a>
          <a class="dropdown-item d-flex align-items-center justify-content-between fw-medium" data-toggle="theme" data-theme="css/themes/smooth.min-5.9.css" href="#">
            <span>Smooth</span>
            <i class="fa fa-circle text-smooth"></i>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item fw-medium" data-toggle="layout" data-action="sidebar_style_light" href="javascript:void(0)">
            <span>Sidebar Light</span>
          </a>
          <a class="dropdown-item fw-medium" data-toggle="layout" data-action="sidebar_style_dark" href="javascript:void(0)">
            <span>Sidebar Dark</span>
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item fw-medium" data-toggle="layout" data-action="header_style_light" href="javascript:void(0)">
            <span>Header Light</span>
          </a>
          <a class="dropdown-item fw-medium" data-toggle="layout" data-action="header_style_dark" href="javascript:void(0)">
            <span>Header Dark</span>
          </a>
        </div>
      </div>
      <a class="d-lg-none btn btn-sm btn-alt-secondary ms-1" data-toggle="layout" data-action="sidebar_close" href="javascript:void(0)">
        <i class="fa fa-fw fa-times"></i>
      </a>
    </div>
  </div>
  <div class="js-sidebar-scroll">
    <div class="content-side">
      <ul class="nav-main">
        <li class="nav-main-item">
<a class="nav-main-link" href="yonetim.php">
<i class="nav-main-link-icon si si-home"></i>
<span class="nav-main-link-name">Anasayfa</span>
</a>
</li>
<li class="nav-main-heading">YOKLAMA</li>
<li class="nav-main-item">
<a class="nav-main-link" href="/yoklama.php">
<i class="nav-main-link-icon si si-check"></i>
<span class="nav-main-link-name">Yoklama Al</span>
</a>
</li>
</li>
      </ul>
    </div>
  </div>
</nav>
  <header id="page-header">
  <div class="content-header">
    <div class="d-flex align-items-center">
      <button type="button" class="btn btn-sm btn-alt-secondary me-2 d-lg-none" data-toggle="layout" data-action="sidebar_toggle">
        <i class="fa fa-fw fa-bars"></i>
      </button>
    </div>
    <div class="d-flex align-items-center">
      <div class="dropdown d-inline-block ms-2">
        <button type="button" class="btn btn-sm btn-alt-secondary d-flex align-items-center" id="page-header-user-dropdown" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <img class="rounded-circle" src="https://static.vecteezy.com/system/resources/previews/005/129/844/non_2x/profile-user-icon-isolated-on-white-background-eps10-free-vector.jpg" style="width: 21px;">
          <span class="d-none d-sm-inline-block ms-2"><?php echo $_SESSION['logined']; ?></span>
          <i class="fa fa-fw fa-angle-down d-none d-sm-inline-block opacity-50 ms-1 mt-1"></i>
        </button>
        <div class="dropdown-menu dropdown-menu-md dropdown-menu-end p-0 border-0" aria-labelledby="page-header-user-dropdown">
          <div class="p-3 text-center bg-body-light border-bottom rounded-top">
            <img class="img-avatar img-avatar48 img-avatar-thumb" src="https://static.vecteezy.com/system/resources/previews/005/129/844/non_2x/profile-user-icon-isolated-on-white-background-eps10-free-vector.jpg" alt="">
            <p class="mt-2 mb-0 fw-medium"><?php echo $_SESSION['logined']; ?></p>
            <p class="mb-0 text-muted fs-sm fw-medium">IP: <?php echo $_SERVER['REMOTE_ADDR']; ?></p>
          </div>
          <div class="p-2">
            <a class="dropdown-item d-flex align-items-center justify-content-between" href="/logout.php">
              <span class="fs-sm fw-medium">Çıkış Yap</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="page-header-search" class="overlay-header bg-body-extra-light">
    <div class="content-header">
    </div>
  </div>
  <div id="page-header-loader" class="overlay-header bg-body-extra-light">
    <div class="content-header">
      <div class="w-100 text-center">
        <i class="fa fa-fw fa-circle-notch fa-spin"></i>
      </div>
    </div>
  </div>
</header>
  <main id="main-container">
<div class="bg-body-light">
  <div class="content content-full">
    <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center py-2">
      <div class="flex-grow-1">
        <h1 class="h3 fw-bold mb-1">
        Dijital Sınıf Defteri / Yoklama
        </h1>
        <h2 class="fs-base lh-base fw-medium text-muted mb-0">
        Yoklamalar 08:00 - 17:00 saatleri arasında alınabilmektedir.
        </h2>
      </div>
      <nav class="flex-shrink-0 mt-3 mt-sm-0 ms-sm-3" aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-alt">
          <li class="breadcrumb-item">
            <a class="link-fx" href="javascript:void(0)">Dijital Sınıf Defteri</a>
          </li>
          <li class="breadcrumb-item" aria-current="page">
            Yoklama Al
          </li>
        </ol>
      </nav>
    </div>
  </div>
</div>
    <div class="content">
        <?php 
        
        if (isset($_GET["sinif"]) && isset($_GET["sube"]) && isset($_GET["ders"])) {

          $ySinif = $_GET["sinif"];
          $ySube = $_GET["sube"];
          $yDers = $_GET["ders"];

   $sql = "SELECT * FROM ogrenciler WHERE sinif = ? AND sube = ?";
  $getir = $conn->prepare($sql);
  $getir->bind_param("ss", $ySinif, $ySube);
  $getir->execute();
  $result = $getir->get_result();
  $resultArr = array();
  
  if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
    array_push($resultArr, $row);
  }
  };

          echo '<div class="block block-rounded">
    <div class="block-header block-header-default">
      <h3 class="block-title">Yoklama Listesi</h3>
    </div>
    <div class="block-content">
      <p class="fs-sm text-muted">
        '.$ySinif."/".$ySube.' şubesi için yoklama listesi.
      </p>
      <div class="table-responsive">
      <form method="POST" action="/yoklama2.php">
        <table class="table table-bordered table-striped table-vcenter">
          <thead>
            <tr>
              <th class="text-center" style="width: 100px;">
                <i class="far fa-user"></i>
              </th>
              <th>isim</th>
              <th style="width: 30%;">Soyisim</th>
              <th style="width: 15%;">Numara</th>
              <th class="text-center" style="width: 100px;">İşlem</th>
            </tr>
          </thead>
          <tbody>';
          foreach ($resultArr as $ogr) {
            echo "
            <tr>
            <td class='text-center'>
              <img class='img-avatar img-avatar48' src='https://static.vecteezy.com/system/resources/previews/005/129/844/non_2x/profile-user-icon-isolated-on-white-background-eps10-free-vector.jpg'>
            </td>
            <td class='fw-semibold fs-sm'>
              <a>{$ogr['isim']}</a>
            </td>
            <td class='fs-sm fw-semibold'><a>{$ogr['soyisim']}</a></td>
            <td>
              <a>{$ogr['numara']}</a>
            </td>
            <td class='text-center'>
                    <div class='form-check'>
                    <input type='text' name='hangiDers' value='$yDers' hidden>
                        <label>
                            <input type='checkbox' name='yok[]' value='{$ogr['numara']}'> Yok
                        </label>
                    </div>
                    <div class='form-check'>
                        <label>
                            <input type='checkbox' name='gec[]' value='{$ogr['numara']}'> Geç
                        </label>
                    </div>
                </td>
          </tr>
         ";
          }
          echo '</tr>
        </tbody>
    </table>
    <button type="submit" class="btn btn-primary">Yoklamayı Kaydet</button>
    <br><br>
    </form>
  </div>
</div>
</div>';
        } else {
            //sınıf ve şube seçince şuanki zaman aralığındaki dersi dbden çekebilir + datatable yapılcak
            echo '<h2 class="content-heading">YOKLAMA OLUŞTUR</h2>
  <p>';
            echo '<div class="mb-4">
              <label class="form-label" for="sinifSec">Sınıf</label>
              <select class="form-select" id="sinifSec" name="sinifSec">
                <option selected="">Seçim yapın</option>
                <option value="9dokuz">9</option>
                <option value="10on">10</option>
                <option value="11onbir">11</option>
                <option value="12oniki">12</option>
              </select>
              <br>
              <label class="form-label" for="subeSec">Şube</label>
              <select class="form-select" id="subeSec" name="subeSec">
                <option value="0">Seçim yapın</option>
                <option value="sinifA">A</option>
                <option value="sinifB">B</option>
                <option value="sinifC">C</option>
                <option value="sinifD">D</option>
                <option value="sinifE">E</option>
                <option value="sinifF">F</option>
              </select>
              <br>
              <label class="form-label" for="dersSec">Ders</label>
              <select class="form-select" id="dersSec" name="dersSec">
                <option value="0">Seçim yapın</option>
                <option value="ders1">1</option>
                <option value="ders2">2</option>
                <option value="ders3">3</option>
                <option value="ders4">4</option>
                <option value="ders5">5</option>
                <option value="ders6">6</option>
                <option value="ders7">7</option>
                <option value="ders8">8</option>
                <option value="ders9">9</option>
                <option value="ders10">10</option>
              </select>
              <br>
              <button type="button" onclick="yoklama();" class="btn btn-primary">Yoklamayı Al</button>
            </div>';
        }
        ?>
    </div>
  </main>
  <footer id="page-footer" class="bg-body-light">
  <div class="content py-3">
    <div class="row fs-sm">
      <div class="col-sm-6 order-sm-2 py-1 text-center text-sm-end">
        Developed with <i class="fa fa-heart text-danger"></i> by <a class="fw-semibold" href="https://hhktml.meb.k12.tr/" target="_blank">H.H.K.M.T.A.L</a>
      </div>
      <div class="col-sm-6 order-sm-1 py-1 text-center text-sm-start">
        <a class="fw-semibold" href="https://hhktml.meb.k12.tr/" target="_blank">H.H.K.M.T.A.L</a> &copy; <span data-toggle="year-copy"></span>
      </div>
    </div>
  </div>
</footer>
</div>
<script src="js/jquery.min.js"></script>
<script src="js/oneui.app.min-5.9.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="js/alert.js"></script>
<script src="js/yoklama.js"></script>
</body>
</html>
