-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 19 Ara 2024, 21:14:15
-- Sunucu sürümü: 10.4.32-MariaDB
-- PHP Sürümü: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `defter`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `devamsizlik`
--

CREATE TABLE `devamsizlik` (
  `id` int(11) NOT NULL,
  `ogrDevamsizlik` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `ders` int(11) NOT NULL,
  `ogrNumara` int(11) NOT NULL,
  `tarih` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `devamsizlik`
--

INSERT INTO `devamsizlik` (`id`, `ogrDevamsizlik`, `ders`, `ogrNumara`, `tarih`) VALUES
(1, 'Yok', 1, 353, '19.12.2024'),
(2, 'Geç', 1, 357, '19.12.2024'),
(3, 'Yok', 2, 353, '19.12.2024'),
(4, 'Yok', 2, 357, '19.12.2024'),
(5, 'Geç', 3, 353, '19.12.2024'),
(6, 'Yok', 6, 353, '19.12.2024'),
(7, 'Yok', 6, 357, '19.12.2024'),
(8, 'Yok', 6, 353, '19.12.2024'),
(9, 'Yok', 6, 357, '19.12.2024'),
(10, 'Yok', 6, 353, '19.12.2024'),
(11, 'Yok', 6, 357, '19.12.2024'),
(12, 'Geç', 7, 357, '19.12.2024'),
(13, 'Geç', 7, 357, '19.12.2024'),
(14, 'Yok', 1, 354, '19.12.2024'),
(15, 'Geç', 2, 354, '19.12.2024'),
(16, 'Geç', 3, 354, '19.12.2024');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogrenciler`
--

CREATE TABLE `ogrenciler` (
  `id` int(11) NOT NULL,
  `tc` text NOT NULL,
  `isim` text NOT NULL,
  `soyisim` text NOT NULL,
  `numara` int(11) NOT NULL,
  `sinif` int(11) NOT NULL,
  `sube` text NOT NULL,
  `ozurlu` int(11) NOT NULL,
  `ozursuz` int(11) NOT NULL,
  `gec` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `ogrenciler`
--

INSERT INTO `ogrenciler` (`id`, `tc`, `isim`, `soyisim`, `numara`, `sinif`, `sube`, `ozurlu`, `ozursuz`, `gec`) VALUES
(1, '13226685968', 'MERT ALİ', 'PARTAL', 353, 12, 'C', 0, 5, 1),
(2, '13226685969', 'MERT', 'PARTAL', 354, 12, 'A', 0, 1, 2),
(3, '13226685960', 'MERTCAN', 'PARTAL', 355, 11, 'B', 0, 0, 0),
(4, '13226685966', 'MERT ALİ', 'KARTAL', 357, 12, 'C', 0, 4, 3);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ogretmenler`
--

CREATE TABLE `ogretmenler` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `ogretmenler`
--

INSERT INTO `ogretmenler` (`id`, `username`, `password`) VALUES
(1, 'mert', '12345');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `devamsizlik`
--
ALTER TABLE `devamsizlik`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ogrenciler`
--
ALTER TABLE `ogrenciler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ogretmenler`
--
ALTER TABLE `ogretmenler`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `devamsizlik`
--
ALTER TABLE `devamsizlik`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Tablo için AUTO_INCREMENT değeri `ogrenciler`
--
ALTER TABLE `ogrenciler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Tablo için AUTO_INCREMENT değeri `ogretmenler`
--
ALTER TABLE `ogretmenler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
