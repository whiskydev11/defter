async function kazanimForm() {
    let formm = document.getElementById("kazanimFormu");
    let sinif = document.getElementById("sinifSec");
    let sube = document.getElementById("subeSec");
    let ders = document.getElementById("dersSec");
    let sinifD = sinif.options[sinif.selectedIndex].text;
    let subeD = sube.options[sube.selectedIndex].text;
    let dersD = ders.options[ders.selectedIndex].text;
    let dersKazanim = document.getElementById("dersKazanimi").value;;
    let imza = document.getElementById("signature-data").value;

    if (sinifD == "Seçim yapın") {
        Swal.fire({
            icon: "error",
            title: "Hata!",
            text: `Lütfen sınıf seçin!`,
          });
          return;
    };

    if (subeD == "Seçim yapın") {
        Swal.fire({
            icon: "error",
            title: "Hata!",
            text: `Lütfen şube seçin!`,
          });
          return;
    };

    if (dersD == "Seçim yapın") {
        Swal.fire({
            icon: "error",
            title: "Hata!",
            text: `Lütfen ders seçin!`,
          });
          return;
    };

    if (!dersKazanim) {
        Swal.fire({
            icon: "error",
            title: "Hata!",
            text: `Lütfen ders kazanımını doldurun!`,
          });
          return;
    };

    if (!imza) {
        Swal.fire({
            icon: "error",
            title: "Hata!",
            text: `Lütfen imzanızı atın!`,
          });
          return;
    };

    await formm.submit();
};