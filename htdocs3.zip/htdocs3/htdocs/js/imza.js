const canvas = document.getElementById('signature-pad');
const clearButton = document.getElementById('clear');
const saveButton = document.getElementById('save');
const signatureForm = document.getElementById('signature-form');
const signatureData = document.getElementById('signature-data');
const ctx = canvas.getContext('2d');
let isDrawingEnabled = true;

canvas.width = 400;
canvas.height = 200;

let isDrawing = false;

canvas.addEventListener('mousedown', (e) => {
    if (!isDrawingEnabled) return;
    isDrawing = true;
    ctx.beginPath();
    ctx.moveTo(e.offsetX, e.offsetY);
});

canvas.addEventListener('mousemove', (e) => {
    if (!isDrawing || !isDrawingEnabled) return;
    ctx.lineTo(e.offsetX, e.offsetY);
    ctx.stroke();
});

canvas.addEventListener('mouseup', () => {
    isDrawing = false;
});

clearButton.addEventListener('click', () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    isDrawingEnabled = true;
});

saveButton.addEventListener('click', () => {
    isDrawingEnabled = false;
    const dataURL = canvas.toDataURL('image/png');
    signatureData.value = dataURL;
    clearButton.disabled = true;
    saveButton.disabled = true;
});