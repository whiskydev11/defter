<?php

session_start();

require 'auth_control.php';

require 'baglan.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $sinif = $_POST["sinifSec"];
    $ders = substr($_POST['dersSec'], 4);
    $dersAdi = $_POST["dersAdi"];
    $sube = substr($_POST['subeSec'], 5);
    $kazanim = $_POST['dersKazanimi'];
    $imza = $_POST['signature'];

    //kontroller eklenecek
    
    if ($sinif == "9dokuz") {
        $sinif = 9;
    } elseif ($sinif == "10on") {
        $sinif = 10;
    } elseif ($sinif == "11onbir") {
        $sinif = 11;
    } elseif ($sinif == "12oniki") {
        $sinif = 12;
    };

    $stmt = $conn->prepare("INSERT INTO ders (sinif, sube, ders, dersAdi, kazanim, imza, ogretmen, tarih) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$sinif, $sube, $ders, $dersAdi, $kazanim, $imza, $_SESSION["logined"], date("d.m.Y")]);

    header("Location: /yonetim.php?s=Ders kazanımı başarıyla kaydedildi.");
};

?>