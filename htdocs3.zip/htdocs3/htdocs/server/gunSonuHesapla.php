<?php
//cronjob ile her saat 17:00 oldugunda calısacak
require 'baglan.php';

$tarih = date("d.m.Y");

$stmt = $conn->prepare("SELECT * FROM devamsizlik WHERE tarih = ?");
$stmt->execute([$tarih]);
$resultSet = $stmt->get_result();
$yoklama = $resultSet->fetch_all(MYSQLI_ASSOC);
$devamsizliklar = [];

foreach ($yoklama as $veri) {
    $ogrenci = $veri["ogrNumara"];

    if (!isset($devamsizliklar[$ogrenci])) {
        $devamsizliklar[$ogrenci] = [];
    };

    $devamsizliklar[$ogrenci][] = $veri;
};

foreach ($devamsizliklar as $veri2) {
    //$veri2 ile ilk sıradaki öğrencinin gün içindeki tüm devamsızlıkları aldık ve tek tek dönüyoruz
    $ogrYokFiltered = array_filter($veri2, function ($z) { return $z["ogrDevamsizlik"] === "Yok"; });
    $ogrGecFiltered = array_filter($veri2, function ($z) { return $z["ogrDevamsizlik"] === "Geç"; });

    if (count($ogrYokFiltered) > 9) {
        //tüm dersler yok, tam gün
        $stmt = $conn->prepare("UPDATE ogrenciler SET ozursuz = ozursuz + 1 WHERE numara = ?");
        $stmt->execute([$veri2[0]["ogrNumara"]]);
    } elseif (count($ogrYokFiltered) < 10) {
        //toplam 10 ders var ve 10 ders yok yazılmamış o yüzden yarım gün
        $stmt = $conn->prepare("UPDATE ogrenciler SET ozursuzYarimGun = ozursuzYarimGun + 1 WHERE numara = ?"); //başka hesaplama yapılırsa yarım gün 0.5 olarak sayılarak bölüm işlemi yapılacak
        $stmt->execute([$veri2[0]["ogrNumara"]]);
    };
      
    /*
    //burada eğer 1 ve 2. ders geç yazıldıysa yarım gün yazılacak, gerisi geç olarak yazılacak
    if () {
       
        $stmt = $conn->prepare("UPDATE ogrenciler SET ozursuz = ozursuz + 1 WHERE numara = ?");
        $stmt->execute([$veri2["ogrNumara"]]);
    }
        */
};
?>