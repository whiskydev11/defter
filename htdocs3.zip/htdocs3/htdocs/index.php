<!doctype html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>Dijital Sınıf Defteri</title>
    <link rel="stylesheet" id="css-main" href="css/oneui.min-5.9.css">
</head>
<body>
<div id="page-container" class="page-header-dark dark-mode">
    <main id="main-container">
<div class="hero-static d-flex align-items-center">
  <div class="content">
    <div class="row justify-content-center push">
      <div class="col-md-8 col-lg-6 col-xl-4">
        <div class="block block-rounded mb-0">
          <div class="block-header block-header-default">
            <h3 class="block-title">Giris Yap</h3>
          </div>
          <div class="block-content">
            <div class="p-sm-3 px-lg-4 px-xxl-5 py-lg-5">
              <h1 class="h2 mb-1">DİJİTAL SINIF DEFTERİ</h1>
              <p class="fw-medium text-muted">
                Sisteme erişmek için giriş yapınız.
              </p>
              <form class="js-validation-signin" method="POST">
                <div class="py-3">
                  <div class="mb-4">
                    <input type="text" class="form-control form-control-alt form-control-lg" id="username" name="username" placeholder="Kullanıcı adı" required>
                    <br>
                    <input type="password" class="form-control form-control-alt form-control-lg" id="password" name="password" placeholder="Şifre" required>
                  </div>
                </div>
                <div class="row mb-4">
                  <div class="col-md-6 col-xl-5">
                    <button type="submit" class="btn btn-block btn-alt-primary">
                      <i class="fa fa-fw fa-sign-in-alt me-1 opacity-50"></i> Giriş Yap
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="fs-sm text-muted text-center">
      <strong>H.H.K.M.T.A.L</strong> &copy; <span data-toggle="year-copy"></span>
    </div>
  </div>
</div>
  </main>
  </div>
<script src="js/oneui.app.min-5.9.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="js/alert.js"></script>
</body>
</html>
<?php

require './server/baglan.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if(isset($_SESSION['logined'])){
        header("Location: /yonetim.php");
    }

  $username = htmlspecialchars($_POST['username']);
  $password = htmlspecialchars($_POST['password']);
 
  if(isset($username) && isset($password)) {
  $sql = "SELECT * FROM ogretmenler WHERE username = ? AND password = ?";
  $kontrolEt = $conn->prepare($sql);
  $kontrolEt->bind_param("ss", $username, $password);
  $kontrolEt->execute();
  $result = $kontrolEt->get_result();
  
  if ($result->num_rows > 0) {
    $row = $result->fetch_array();

    if ($row) {
        $_SESSION['logined'] = $row['username'];
        $_SESSION['loginedId'] = $row['id'];

        header("Location: /yonetim.php?s=Başarıyla giriş yapıldı.");
      } else {
       header("Location: /?e=Kullanıcı adı veya şifre yanlış.");
      }
  } else {
    header("Location: /?e=Kullanıcı adı veya şifre yanlış.");
  }
} else {
    header("Location: /?e=Giriş bilgileri eksik girildi.");
}
}
?>
