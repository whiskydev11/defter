let url = new URLSearchParams(window.location.search);

if (url.get('s')) {
 
    Swal.fire({
        icon: "success",
        title: "Başarılı!",
        text: `${url.get('s').toString()}`,
      });
}

if (url.get('e')) {

    Swal.fire({
        icon: "error",
        title: "Hata!",
        text: `${url.get('e').toString()}`,
      });
}