<?php

if (!isset($_SESSION["logined"])) {
  header("Location: /");
}

?>